# Ebook GUI Generator

This tool allows you to generate branded PDF ebooks using a simple graphical interface (GUI).

## How to Use:
1. Launch the app with: `python3 gui_books.py`
2. Select your `book_data.csv` file.
3. Click 'Generate Books'.
4. Your PDFs will appear in the `output/` folder.

Requirements:
- Python 3
- Tkinter (usually pre-installed on Linux)
- Your OpenAI API key saved in `api_key.txt`

Support:
Ricky Jarnagin's Practical Publishing Project
