---
title: "Spiritual Warfare in Your Browser Tabs"
layout: doc
tags: [focus, distraction, spiritual]
outline: [2,3]
---

# 🧠 Spiritual Warfare in Your Browser Tabs

We don’t fight against flesh and blood — but maybe against infinite scroll.

## 💻 Every Tab Is a Portal

Distraction doesn’t just cost you time — it costs you attention, identity, and peace.

## 🛡️ What You Click Shapes What You Crave

Some clicks feed your spirit.  
Others feed your anxiety.

Guard your gaze.

> “Above all else, guard your heart, for everything you do flows from it.” — Proverbs 4:23
